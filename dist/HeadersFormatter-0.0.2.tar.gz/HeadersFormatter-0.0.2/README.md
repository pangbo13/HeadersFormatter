# HeadersFormatter
Format headers in clipboard to <dict>.

将剪贴板中的Headers格式化为<dict>并返回剪贴板
